// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.2 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================

extern void AESL_WRAP_myproject (
hls::stream<struct nnet::array<ap_fixed<32, 16, (ap_q_mode) 5, (ap_o_mode)3, 0>, 32 > > (&input_1),
hls::stream<struct nnet::array<ap_fixed<32, 16, (ap_q_mode) 5, (ap_o_mode)3, 0>, 1 > > (&layer2_out));
